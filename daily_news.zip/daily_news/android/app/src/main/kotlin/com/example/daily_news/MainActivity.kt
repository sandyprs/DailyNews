package com.example.daily_news

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

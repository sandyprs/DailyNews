import 'package:daily_news/NewsList.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'NewsFetch.dart';
import 'NewsData.dart';

class LoadingScreen extends StatefulWidget {
  @override
  _LoadingScreenState createState() => _LoadingScreenState();
}

class _LoadingScreenState extends State<LoadingScreen> {
  List<NewsData> _items = List<NewsData>();
  @override
  void initState() {
    super.initState();
    var items = NewsFetch().getNewsData();
    items.then((value) {
      _items.addAll(value);
      Navigator.pushReplacement(context,MaterialPageRoute(builder: (context) {
        return NewsList(items: _items);
      }));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black,
      child: Center(
        child: SpinKitWave(
          size: 50.0,
          color: Colors.blueAccent,
        ),
      ),
    );
  }
}

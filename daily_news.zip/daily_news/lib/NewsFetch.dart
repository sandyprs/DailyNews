import 'dart:convert';
import 'package:daily_news/NewsData.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';

const url =
    "https://news67.p.rapidapi.com/top/about-country?country=in&limit=15&langs=en&skip=0";
const apiKey = 'c119025ea2mshb5daa7cbb2dcb4ap108444jsn5cedb1ec3ec9';

class NewsFetch {
  Future<List<NewsData>> getNewsData() async {
    List<NewsData> list = List<NewsData>();

    var response = await http.get(url, headers: {
      'x-rapidapi-host': "news67.p.rapidapi.com",
      'x-rapidapi-key': apiKey
    });
    if (response.statusCode == 200) {
      var jsonResponse = jsonDecode(response.body);
      //print(jsonResponse);

      for (var news in jsonResponse) {
        list.add(NewsData.fromJson(news));
      }
    } else {
      Fluttertoast.showToast(
          msg: 'error from API',
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          fontSize: 15.0);
    }
    return list;
  }
}

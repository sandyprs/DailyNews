import 'package:flutter/material.dart';

class NewsDtails extends StatefulWidget {
  final String title;
  final String desc;
   String imgUrl;
  NewsDtails({this.title, this.desc,this.imgUrl});

  @override
  _NewsDtailsState createState() => _NewsDtailsState(title: title, desc: desc,imgUrl: imgUrl);
}

class _NewsDtailsState extends State<NewsDtails> {
  String title;
  String desc;
  String imgUrl;
  _NewsDtailsState({
    this.title,
    this.desc,
    this.imgUrl
  });
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Material(
        color: Colors.black12,
        child: Container(
          padding: EdgeInsets.all(10.0),
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minHeight: 100,
              ),
              child: Container(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Image(
                  image: NetworkImage(imgUrl),
                ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        title,
                        textAlign: TextAlign.left,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 30.0,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Text(
                        desc,
                        textAlign: TextAlign.justify,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

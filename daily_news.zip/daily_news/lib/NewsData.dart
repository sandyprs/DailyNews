class NewsData {
  String title;
  String description;
  String summery;
  String imgUrl;
  String date;

  NewsData(
      {this.title, this.description, this.date, this.summery, this.imgUrl});

  NewsData.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    description = json['description'];
    summery = json['summarization'];
    imgUrl = json['image'];
    date = json['publishedDate'];
  }
}

import 'package:daily_news/NewsData.dart';
import 'package:daily_news/NewsDetails.dart';
import 'package:flutter/material.dart';

class NewsList extends StatefulWidget {
  List<NewsData> items;
  NewsList({this.items});

  @override
  _NewsListState createState() => _NewsListState(items: this.items);
}

class _NewsListState extends State<NewsList> {
  List<NewsData> items;
  _NewsListState({this.items});
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0)),
          ),
          backgroundColor: Colors.blue,
          centerTitle: true,
          title: Text(items[0].date),
        ),
        body: ListView.builder(
          itemCount: items.length,
          itemBuilder: (context, index) {
            return cardList(context, index);
          },
        ),
      ),
    );
  }

  Widget cardList(BuildContext context, int index) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => NewsDtails(
                      title: items[index].title,
                      desc: items[index].description,
                      imgUrl: items[index].imgUrl,
                    )));
      },
      child: Card(
        margin: EdgeInsets.fromLTRB(8, 5, 8, 3),
        color: Colors.blue,
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minHeight: 100,
          ),
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image(
                  image: NetworkImage(items[index].imgUrl),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    items[index].title,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 25.0,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    items[index].summery,
                    textAlign: TextAlign.left,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 13.0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
